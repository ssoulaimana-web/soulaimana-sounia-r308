# R3.08 · POO Python — BUT RT2

Travaux pratiques de Sounia Soulaimana. Python 3.10 ou plus, aucune dépendance externe.

```
soulaimana-sounia-r308/
├── tp1/   Gestion de données et mini-jeux
├── tp2/   POO et jeu du Morpion
└── tp3/   Gestion d'une bibliothèque
```

Chaque TP se lance **depuis son dossier** (`cd tp1`, etc.).

## TP1 — Gestion de données et mini-jeux

| Partie | Fichier | Lancer |
|---|---|---|
| A · Dictionnaire d'étudiants | `partie_a.py` | `python partie_a.py` |
| B · Devine le nombre | `partie_b.py` | `python partie_b.py` |
| C · Manipulation des mots | `mots.py` (+ `mots.txt`) | `python mots.py` |
| D · Jeu du Pendu | `pendu.py` | `python pendu.py` |
| Bonus · Hall of fame | `scores.py` (utilisé par `pendu.py`) | écrit `scores.txt` |

- Le Pendu gère les mots accentués et en casse mixte (`ÉLÉPHANT`, `Python`) : taper `e` révèle les `É`.
- Mode 2 joueurs : choisir « 2 » au lancement, le mot est saisi sans écho (tournoi du Pendu).
- Défaite à la 7ᵉ erreur ; une lettre déjà proposée ne compte pas d'erreur.

## TP2 — POO et jeu du Morpion

| Partie | Fichier |
|---|---|
| A · Classe `Grille` | `grille.py` |
| B · `JoueurHumain`, `JoueurIA` (+ `JoueurIAMalin`) | `joueurs.py` |
| C · Jeu complet | `morpion.py` |

Lancer : `python morpion.py` (4 modes : humain/IA, humain/IA maligne, 2 humains, IA contre IA sur 20 parties).
Les coordonnées se saisissent `ligne colonne` de 0 à 2 (ex. `1 2`).

## TP3 — Gestion d'une bibliothèque

| Partie | Fichier |
|---|---|
| A · `Livre`, `Utilisateur` | `livre.py`, `utilisateur.py` |
| B · `Bibliotheque` | `bibliotheque.py` |
| C · Persistance CSV | `bibliotheque.py` (`sauvegarder` / `charger`) |
| D · Programme principal | `main.py` |
| E · Extensions | recherche par auteur (menu 8), limite d'emprunts, export JSON |

Lancer : `python main.py`. Les données sont sauvegardées dans `tp3/donnees/`
(`livres.csv` et `utilisateurs.txt`) à la sortie (choix 6) et rechargées au lancement.
Le menu propose aussi les statistiques (7).

## Tests

```
cd tp1 && python test_tp1.py
cd tp2 && python test_tp2.py
cd tp3 && python test_tp3.py
```
