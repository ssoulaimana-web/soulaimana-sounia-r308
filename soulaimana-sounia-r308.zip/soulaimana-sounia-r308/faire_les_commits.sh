#!/bin/sh
# Crée l'historique Git : un commit par partie. À lancer une seule fois, à la
# racine du dossier, avec ton identité Git déjà configurée
# (git config --global user.name / user.email).
set -e

git init -b main
c() { message=$1; shift; git add "$@"; git commit -m "$message"; }

c "Initialisation du dépôt" README.md .gitignore

c "TP1 partie A" tp1/partie_a.py
c "TP1 partie B" tp1/partie_b.py
c "TP1 partie C" tp1/mots.py tp1/mots.txt
c "TP1 partie D" tp1/pendu.py tp1/scores.py
c "TP1 tests" tp1/test_tp1.py

c "TP2 partie A" tp2/grille.py
c "TP2 partie B" tp2/joueurs.py
c "TP2 partie C" tp2/morpion.py
c "TP2 tests" tp2/test_tp2.py

c "TP3 partie A" tp3/livre.py tp3/utilisateur.py
c "TP3 partie B" tp3/bibliotheque.py
c "TP3 partie D" tp3/main.py
c "TP3 tests" tp3/test_tp3.py

git log --oneline
echo
echo "Ensuite : crée un dépôt public vide sur GitHub, puis"
echo "  git remote add origin https://github.com/<ton-compte>/soulaimana-sounia-r308.git"
echo "  git push -u origin main"
